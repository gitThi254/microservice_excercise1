package com.example.eurukaService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EurukaServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(EurukaServiceApplication.class, args);
	}

}
